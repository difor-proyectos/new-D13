# Copiloto Comercial - Cloudflare Pages

Configuración requerida en Cloudflare Pages:

- Build command: vacío
- Output directory: `/` o vacío
- D1 binding: `DB` -> base de datos `copiloto`
- R2 binding recomendado: `BUCKET` -> bucket `copiloto`

Importante: este proyecto incluye `_worker.js`, por eso NO se debe usar `ASSETS` como nombre del R2. `ASSETS` puede chocar con el binding interno de Cloudflare Pages para archivos estáticos.

Verificación:

- `/api/health` debe devolver JSON.
- En el JSON debe aparecer `r2Binding: "BUCKET"`.

Si `/api/health` devuelve HTML, Cloudflare no está ejecutando el Worker.
