# Product brand spec for DIFOR Chiloé prototype

Source: project memory, "Product visual direction".

## Color tokens

- `--bg`: `oklch(100% 0 0)` from `#ffffff`
- `--surface`: `oklch(97.7% 0.003 247)` from `#f7f8fa`
- `--fg`: `oklch(17.8% 0 0)` from `#111111`
- `--muted`: `oklch(55.1% 0.023 264)` from `#6b7280`
- `--border`: `oklch(90.8% 0.012 258)` from `#d9dee7`
- `--accent`: `oklch(57.2% 0.191 258)` from `#1677ff`

## Type

- Display: `Inter, system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif`
- Body: `Inter, system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif`
- Mono: `ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`

## Layout posture

- 8px radius for cards, buttons, inputs and panels.
- 1px borders define structure; avoid heavy shadows.
- 8px baseline grid for spacing and module sizing.
- Accent blue is reserved for primary actions, current navigation and focused states.
- Home stays minimal: logo text, Copiloto Comercial, and exactly six equal module buttons.
